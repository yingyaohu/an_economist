% this code is to conduct eigenvalue-egenvector decomposition to estimate
% self-reported matrix and transtript-reported matrix.
% identification relies on the following two equations:
% Eq1: int_y y f(y,x1,x2)dy=E(y|x1,x2) Pr(x1,x2)= int_x* E(y|x*) f(x1|x*)f(x2|x*)f(x*)
% Eq2: f(x1,x2) =int_x* f(x1|x*)f(x2|x*)f(x*)
% Matrix definition: Fy_{i,j}=E(y|x1=i,x2=j)Pr(x1=i,x2=j),S_{i,j}=f(x1=i|x*=j),T_{i,j}=f(x2=i|x*=j)
% Dy_{i}=diag{E(y|x*=i)f(x*=i)},Fx_{i,j}=Pr(x1=i,x2=j), Dx_{i}=diag{f(x*=i)}
% Matrix representation Eq1: Fy=S*Dy*T', Eq2: Fx=S*Dx*T'
% main eq: Fy*Fx^{-1}=S*D*S^{-1};Fy'*Fx'^{-1}=T*D*T^{-1}

function [S,T,Returns]=decomposition(x1,x2,y)

K=length(unique(x1)); % the education is group into nc=3 categories: High School (1), Some College(2), and Bachelor(3)

Fy=zeros(K);
Fx=zeros(K);
nobs=length(y);

for i=1:K
    for j=1:K
    id_ij=(x1==i)&(x2==j);
    Fx(i,j)=sum(id_ij)/nobs;
        if sum(id_ij)==0  % this is to handle the case that there is no observation of x1=i, x2=j in the data
           Fy(i,j)=0;
        else
           Fy(i,j)=mean(y(id_ij))*Fx(i,j);
        end
    end
end
    % estimate the mis-reported matrix
    
    [eigv_S,D]=eig(Fy/Fx); %eigen value, eigen vector decomposition
    % only take the real part if the decomposition generates complex value
    U1=real(eigv_S);
    D=real(D);
    % normalization using the column sum equals to 1
    U1=U1./kron(sum(U1),ones(K,1));
    % if the element is negative, force it to be zero as probability cannot
    % be negative
    U1(U1<0)=0;
    % renormalize again
    S=U1./kron(sum(U1),ones(K,1));
    % pin down the location of the underlying education using the fact that returns increases with education attainment
    [Returns_S,index1]=sort(diag(D)); %order the eigen value
    S=S(:,index1);

    
    %estimate the transtript-reported matrix. interchange the locaation of
    %x1 and x2 by inversing the associated matrices Fy and Fx
    [eigv_T,D]=eig(Fy'/Fx'); %eigen value, eigen vector decomposition
    % only take the real part if the decomposition generates complex value
    U1=real(eigv_T);
    D=real(D);
    % normalization using the column sum equals to 1
    U1=U1./kron(sum(U1),ones(K,1));
    % if the element is negative, force it to be zero as probability cannot
    % be negative
    U1(U1<0)=0;
    % renormalize again
    T=U1./kron(sum(U1),ones(K,1));
    % pin down the location of the underlying education using the fact that returns increases with education attainment
    [Returns_T,index1]=sort(diag(D)); %order the eigen value
    T=T(:,index1);

    if sum(abs(Returns_S-Returns_T)<10^(-8))==K  % this is to check whether the returns are estimated to be the same. Allow some computation error
        
        Returns=Returns_S;
    else
        Returns=[];
    end
   
    % calculate the marginal distribution of the unobserved types
    
end
    