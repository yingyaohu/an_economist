This folder includes the data, do.file, and m.file for estimating returns to education when the education in the data is with measurement error

NLS72FIL.dta:            the original download data.
cleardata.do:            the do.file to construct the three categories self-reported and transcript-recorded education variable
Educ_returns.dta(csv):   the data created from cleardata.do and is used for later estimation
Educ_Misclassification.m the main m.file for estimating the error probability matrices and returns to education. 
decomposition.m          the m.file to estimate via eigenvalue-eigenvector decomposition
L2.distance.m            the L2 norm distance between the element estimated from the data and the counterpart represented by the model. 
