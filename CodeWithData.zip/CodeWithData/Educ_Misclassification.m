%%%%% This code is to estimate the returns to education, where 
%%%%% education is with measurement error
%%% I use two different approaches to estimate the error probability matrix
%%%% The first one, the plug-in estimator, follows the identification step-by-step and
%%%% use eigenvalue-eigenvector decomposition 
%%%% The second one, the minimial distance estimtor, estimates the distance
%%%% between the joint distribution calculated from the data and from the
%%%% latent distributions.
%%%% the location of the latent education is pinned down by the condition
%%%% that average returns increase with education.
%%%% The standard errors are computed through bootstrap
%%% Ruli Xiao
%%% 2020-06-08
tic
clc;
clear all;

% loading the data
% S_eduK and T_eduK are the two education information from self-report and
% transtript, where the education is group by K categories, respectively. 
data=csvread('Educ_returns.csv');

% parse out the data
y=data(:,1);
Tedu=data(:,2);  % Transcript-reported education
Sedu=data(:,3);  % self-reported education 

%calculating the fraction of each educational obtainmnet in the samples
K=length(unique(Tedu)); % the education is group into nc=3 categories: High School (1), Some College(2), and Bachelor(3)

nobs=length(Sedu);  % sample size
S_frequency=accumarray(Sedu,1)/nobs; 
T_frequency=accumarray(Tedu,1)/nobs;
Joint_ST=accumarray([Sedu Tedu],1)/nobs;

%eigenvalue-eigenvector decomposition
[S_de,T_de,Returns_de]=decomposition(Sedu,Tedu,y); % S: self-reported probability matrix where S_{i,j}=Pr(X1=i|X*=j)_{i,j}, T is defined in the same way. 
pi_de=S_de\S_frequency; % marginal distribution of the true eduction
% minimum distance estimator using L2 norm
options = optimset('Display','off','TolFun',1e-12,'TolX',1e-8,'MaxIter',20000,'MaxFunEvals',20000);
theta0=generate_initial(S_de,T_de,Returns_de,pi_de,K); % using the estiamtes from the decomposition as the initial values
[theta_m,fvalue,exitflag] = fminunc(@(theta)L2_distance(Sedu,Tedu,y,theta,K),theta0,options); 
[S_min,T_min,Returns_min,pi_min]=get_parameter(theta_m,K); % parse out the estimates
% order the latent education  using that average returns increases with education level


%% bootstrap to compute standard error
rs = RandStream('mcg16807','Seed',1211); %  set the seed 121212
RandStream.setGlobalStream(rs);
nb=500;  % number of bootstrap samples
boot_sample=ceil(rand(nobs,nb)*nobs);
% to store the estimates for each bootstrap sample
% store the results from decomposition
S_b_all_de=zeros(K^2,nb);
T_b_all_de=zeros(K^2,nb);
returns_all_de=zeros(K,nb);
pi_all_de=zeros(K,nb);
% store the results from minimizing distance
S_b_all_min=zeros(K^2,nb);
T_b_all_min=zeros(K^2,nb);
returns_all_min=zeros(K,nb);
pi_all_min=zeros(K,nb);

for k=1:nb

    y_boot=y(boot_sample(:,k));
    S_boot=Sedu(boot_sample(:,k));
    T_boot=Tedu(boot_sample(:,k));
    % bootstrap to estimate standard error using decomposition
    [S_b,T_b,Returns_b]=decomposition(S_boot,T_boot,y_boot); % S: self-reported probability matrix where S_{i,j}=Pr(X1=i|X*=j)_{i,j}, T is defined in the same way. 
    S_frequency_b=accumarray(S_boot,1)/nobs; 
    S_b_all_de(:,k)=S_b(:);
    T_b_all_de(:,k)=T_b(:);
    returns_all_de(:,k)=Returns_b;
    pi_all_de(:,k)=S_b\S_frequency_b;
    % bootstrap to estimate standard error using minimizing distance
    [theta_B,~,exitflag] = fminunc(@(theta)L2_distance(S_boot,T_boot,y_boot,theta,K),theta_m,options); 
    [S_b,T_b,Returns_b,pi_b]=get_parameter(theta_B,K); % parse out the estimates
    S_b_all_min(:,k)=S_b(:);
    T_b_all_min(:,k)=T_b(:);
    returns_all_min(:,k)=Returns_b;
    pi_all_min(:,k)=pi_b;
end

% test whether the diagonal element being one or not, or the off-diagonal
% element being zero or not.
std_S_min=reshape(std(S_b_all_min,0,2),K,K);
std_T_min=reshape(std(T_b_all_min,0,2),K,K);
std_S_de=reshape(std(S_b_all_de,0,2),K,K);
std_T_de=reshape(std(T_b_all_de,0,2),K,K);
tvalue_S=abs(S_min./std_S_min); % test: off-diagonal element=0
tvalue_T=abs(T_min./std_T_min);
tvalue_S_de=abs(S_de./std_S_de);
tvalue_T_de=abs(T_de./std_T_de);
for k=1:K
    tvalue_S(k,k)=(1-S_min(k,k))/std_S_min(k,k);
    tvalue_T(k,k)=(1-T_min(k,k))/std_T_min(k,k);
    tvalue_S_de(k,k)=(1-S_de(k,k))/std_S_de(k,k);
    tvalue_T_de(k,k)=(1-T_de(k,k))/std_T_de(k,k);
end

%% print the estimates and their standard errors 

% for the minimal distance estimator
disp('for the minimal distance estimator')
disp('the estimates of the self-reported error probability matrix')
S_min
disp('the standard error of the self-reported error probability matrix')
std_S_min

disp('the estimates of the transtript-reported error probability matrix')
T_min
disp('the standard error of the transtript-reported error probability matrix')
std_T_min

disp('estimates of mean wage and marginal probabilities of true education and their std error')
[Returns_min std(returns_all_min,0,2) pi_min std(pi_all_min,0,2)]

% for the plug-in estimator from decomposition
disp('for the plug-in estimator')
disp('the estimates of the self-reported error probability matrix')
S_de
disp('the standard error of the self-reported error probability matrix')
std_S_de

disp('the estimates of the transtript-reported error probability matrix')
T_de
disp('the standard error of the transtript-reported error probability matrix')
std_T_de

disp('estimates of mean wage and marginal probabilities of true education and their std error')
[Returns_de std(returns_all_de,0,2) pi_de std(pi_all_de,0,2)]

toc