function [S,T,Ey,D]=get_parameter(theta,K)


% to guarantee that the probability is nonegative, we use exponential
% transformation of the parameter
% self-reported error probability
theta_S=[reshape(theta(1:(K-1)*K),K-1,K)
         zeros(1,K)];
S=exp(theta_S)./repmat(sum(exp(theta_S)),K,1);
% transcript-recored error probability
theta_T=[reshape(theta((K-1)*K+1:2*(K-1)*K),K-1,K)
         zeros(1,K)];
T=exp(theta_T)./repmat(sum(exp(theta_T)),K,1);
% expected returns to education
Ey = theta(2*(K-1)*K+1:2*(K-1)*K+K);
% marginal probability of each education level
theta_D  = [theta(2*(K-1)*K+K+1:end); 0];
D=exp(theta_D)/sum(exp(theta_D));
end