% Simulation for the estimator using decomposition and minimum distance
%estimator for latent factor
%by Ruli Xiao 2020-08-07

clc;
clear;
tic

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%%  Step 1: drawing sample
%%%  payoff=beta*s+alpha*p_{-i}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%Mis-reported matrices%%%%%%%%%%%
Tran_p=[0.9439 0.0928 0.0291
        0.0557 0.9007 0.0494
        0.0004 0.0065 0.9215];
    
Rep_p=[0.8838 0.0630 0.0001
       0.1049 0.9111 0.0095
       0.0113 0.0259 0.9904];
   
% returns to educations
re_edu=[2.025 2.2074 2.4456]';

% Marginal distribution for each degree level
Mp=[0.3432 0.3022 0.3546]';

%sample size
ns=1000;

nr=1000; %number of replication
s = RandStream('mcg16807','Seed',16668000); %  set the seed
RandStream.setGlobalStream(s);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%%  Step 2: Simulate the data ande estimate the model primitives 
%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
edu_d=3;
theta_true=generate_initial(Rep_p,Tran_p,re_edu,Mp,edu_d);


S_all_de=zeros(edu_d^2,nr);
T_all_de=zeros(edu_d^2,nr);
returns_all_de=zeros(edu_d,nr);
pi_all_de=zeros(edu_d,nr);
% store the results from minimizing distance
S_all_min=zeros(edu_d^2,nr);
T_all_min=zeros(edu_d^2,nr);
returns_all_min=zeros(edu_d,nr);
pi_all_min=zeros(edu_d,nr);

options = optimset('Display','off','TolFun',1e-12,'TolX',1e-8,'MaxIter',20000,'MaxFunEvals',20000);

for k=1:nr
    Data=DrawSample(Tran_p,Rep_p,re_edu,Mp,ns);  
    y_k=Data(:,3);
    S_k=Data(:,2);
    T_k=Data(:,1);
    
    [S_est,T_est,Returns_est]=decomposition(S_k,T_k,y_k); % S: self-reported probability matrix where S_{i,j}=Pr(X1=i|X*=j)_{i,j}, T is defined in the same way. 
    S_frequency=accumarray(S_k,1)/ns; 
    S_all_de(:,k)=S_est(:);
    T_all_de(:,k)=T_est(:);
    returns_all_de(:,k)=Returns_est;
    pi_de=S_est\S_frequency;
    % noramlize the estimate marginal distribution to make sure every
    % element is nonnegative
    pi_de(pi_de<0)=0;
    pi_de=pi_de/sum(pi_de); 
    pi_all_de(:,k)=pi_de;
    %  estimate standard error using minimizing distance
    theta_de=generate_initial(S_est,T_est,Returns_est,pi_de,edu_d);  % I use the estimates from decomposition as the initial value for the minimum distance estimator
    [theta_B,~,exitflag] = fminunc(@(theta)L2_distance(S_k,T_k,y_k,theta,edu_d),theta_de,options);
    exitflag_all(k)=exitflag;
    [S_est,T_est,Returns_est,pi_est]=get_parameter(theta_B,edu_d); % parse out the estimates
    S_all_min(:,k)=S_est(:);
    T_all_min(:,k)=T_est(:);
    returns_all_min(:,k)=Returns_est;
    pi_all_min(:,k)=pi_est;

end

% the mean of the est from replication of 1000 times using the minimum
% distance estimator
S_mean_min=reshape(mean( S_all_min,2),edu_d,edu_d);
T_mean_min=reshape(mean(T_all_min,2),edu_d,edu_d);
Re_mean_min=mean(returns_all_min,2);
Pi_mean_min=mean(pi_all_min,2);

% the mean of the est from replication of 1000 times using the plug-in 
%  estimator
S_mean_de=reshape(mean(S_all_de,2),edu_d,edu_d);
T_mean_de=reshape(mean(T_all_de,2),edu_d,edu_d);
Re_mean_de=mean(returns_all_de,2);
Pi_mean_de=mean(pi_all_de,2);


% test whether the diagonal element being one or not, or the off-diagonal
% element being zero or not.
std_S_min=reshape(std(S_all_min,0,2),edu_d,edu_d);
std_T_min=reshape(std(T_all_min,0,2),edu_d,edu_d);
std_S_de=reshape(std(S_all_de,0,2),edu_d,edu_d);
std_T_de=reshape(std(T_all_de,0,2),edu_d,edu_d);
tvalue_S=abs(S_mean_min./std_S_min); % test: off-diagonal element=0
tvalue_T=abs(T_mean_min./std_T_min);
tvalue_S_de=abs(S_mean_de./std_S_de);
tvalue_T_de=abs(T_mean_de./std_T_de);
for k=1:edu_d
    tvalue_S(k,k)=(1-S_mean_min(k,k))/std_S_min(k,k);
    tvalue_T(k,k)=(1-T_mean_min(k,k))/std_T_min(k,k);
    tvalue_S_de(k,k)=(1-S_mean_de(k,k))/std_S_de(k,k);
    tvalue_T_de(k,k)=(1-T_mean_de(k,k))/std_T_de(k,k);
end

%% print the estimates and their standard errors 

% for the minimal distance estimator
disp('for the minimal distance estimator')
disp('the estimates of the self-reported error probability matrix')
S_mean_min
disp('the standard error of the self-reported error probability matrix')
std_S_min

disp('the estimates of the transtript-reported error probability matrix')
T_mean_min
disp('the standard error of the transtript-reported error probability matrix')
std_T_min

disp('estimates of mean wage and marginal probabilities of true education and their std error')
[re_edu Re_mean_min std(returns_all_min,0,2) Mp Pi_mean_min std(pi_all_min,0,2)]

% for the plug-in estimator from decomposition
disp('for the plug-in estimator')
disp('the estimates of the self-reported error probability matrix')
S_mean_de
disp('the standard error of the self-reported error probability matrix')
std_S_de

disp('the estimates of the transtript-reported error probability matrix')
T_mean_de
disp('the standard error of the transtript-reported error probability matrix')
std_T_de

disp('estimates of mean wage and marginal probabilities of true education and their std error')
[Re_mean_de std(returns_all_de,0,2) Pi_mean_de std(pi_all_de,0,2)]

toc