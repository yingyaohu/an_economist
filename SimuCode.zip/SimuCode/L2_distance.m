% this code is to conduct eigenvalue-egenvector decomposition to estimate
% self-reported matrix and transtript-reported matrix.
% estimation uses minimum distance of the joint distribution from
% the data and from the model
% int_y y f(y,x1,x2)dy =E(y|x1,x2) Pr(x1,x2) = int_x* E(y|x*) f(x1|x*)f(x2|x*)f(x*)
% f(x1,x2) =int_x* f(x1|x*)f(x2|x*)f(x*)
function v=L2_distance(x1,x2,y,theta,K)

% parse out the parameters
[S,T,Ey,D]=get_parameter(theta,K);

% compute the matrix using data
Fy=zeros(K); % int_y y f(y,x1,x2)dy
Fx=zeros(K);
nobs=length(y);

for i=1:K
    for j=1:K
    id_ij=(x1==i)&(x2==j);
    Fx(i,j)=sum(id_ij)/nobs;
        if sum(id_ij)==0  % this is to handle the case that there is no observation of x1=i, x2=j in the data
           Fy(i,j)=0;
        else
           Fy(i,j)=mean(y(id_ij))*Fx(i,j);
        end
    end
end


% compute the matrix in theory
Fy_theory=S*diag(D.*Ey)*T'; % int_x* E(y|x*) f(x1|x*)f(x2|x*)f(x*)
Fx_theory=S*diag(D)*T';
    
% distance between the matrices from the data and theory
theory_vector=[Fy_theory(:)
               Fx_theory(:)];
data_vector=[Fy(:)
             Fx(:)];
         
% objective function using L2 norm
v=sqrt(sum((theory_vector-data_vector).^2));

end