function theta=generate_initial(S,T,Ey,pi,K);


% to guarantee that the probability is nonegative, we use exponential
% transformation of the parameter
theta=[];

% self-reported error probability
S_theta=zeros(K-1,K);
logS=log(S+0.001); % to avoid zero element.
for i=1:K-1
    S_theta(i,:)=logS(i,:)-logS(K,:);
end
theta=[theta
       S_theta(:)];
% transcript-recored error probability
T_theta=zeros(K-1,K);
logT=log(T+0.001); % to avoid zero element.
for i=1:K-1
    T_theta(i,:)=logT(i,:)-logT(K,:);
end
theta=[theta
       T_theta(:)];
% expected returns to education
theta=[theta
       Ey];
% marginal probability of each education level
logp=log(pi+0.001);
theta=[theta
       logp(1:K-1)-logp(K)];
end