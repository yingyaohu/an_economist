function S = DisSamp(x,p,nsimu)
% Generate a random sample S of size ns 
% with replacement from x(1:n) with prob. % density p(1:n), using the discrete 
% inverse transform method. 
% Time Complexity: O(n*ns). 
% 
% USE: S = DiscITSamp1([5 7 8 11], 
% [0.2 0.3 0.4 0.1],1000);hist(S)

myCDF = cumsum(p); 
S = zeros(nsimu,1); 
for k = 1:nsimu 
    u = rand; 
    i = 1; 
    while myCDF(i) <= u 
        i = i+1; 
    end; 
    S(k) = x(i); 
end
end