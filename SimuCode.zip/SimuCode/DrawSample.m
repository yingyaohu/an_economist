function Data=DrawSample(Tran_p,Rep_p,Re_edu,Mp,ns)   

Data=[];

J=length(Mp); % the dimension of the latent factor
educ=1:J; % using number to represent the 
true_edu=DisSamp(educ,Mp,ns); % generate the true education level

        for j=1:J
            id=true_edu==j;  
            ns_j=sum(id);
            Tj=DisSamp(educ,Tran_p(:,j),ns_j);% using the error matrix for transcrpit for educ=j to generate the educ in transcript
            Sj=DisSamp(educ,Rep_p(:,j),ns_j); % using the self-reporting error for educ=j to generate the educ in survey
            Yj=Re_edu(j)+0.5*randn(ns_j,1); % generate the returns to education using the normal disturbance N(0,0.5^2)
            Data=[Data
                  Tj Sj Yj];
        end

 
end